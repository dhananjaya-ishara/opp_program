/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.q15;

/**
 *
 * @author Dilshan
 */
public class Q15 {

    public static void main(String[] args) {
        calculator c1=new calculator();
        c1.show(true);  
    }
}
