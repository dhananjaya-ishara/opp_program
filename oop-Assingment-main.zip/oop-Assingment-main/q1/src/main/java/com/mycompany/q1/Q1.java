
package com.mycompany.q1;

public class Q1 {

    public static void main(String[] args) {
        //decrea the name
        String name="dilshan";
        System.out.println("hey :" + name);
    }
}
