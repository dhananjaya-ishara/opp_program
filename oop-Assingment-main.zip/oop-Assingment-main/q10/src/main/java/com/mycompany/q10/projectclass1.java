
package com.mycompany.q10;

public class projectclass1 implements debugging {
    @Override
    public void debug(){
        System.out.println("degugging projectclass1:");
    }
    
}