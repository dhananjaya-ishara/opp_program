
package com.mycompany.q10;

public  class square extends shape {//sub calss

    
    @Override
    public  void nameddraw (){
         System.out.println("draw the circle: ");
           
    }
    @Override
    public  void erase (){
         System.out.println("draw the erase:");
         
     }
}
