
package com.mycompany.q10;

public  class circle extends shape{//suc class
    
    @Override
    public void nameddraw (){
         System.out.println("draw the circle: ");
           
    }
    @Override
     public void erase (){
         System.out.println("draw the erase:");
         
     }
    
}
