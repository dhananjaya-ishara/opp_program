
package com.mycompany.q10;

public class project {

    
    //base calll
    public void debug(debugging debugging){
        debugging.debug();
    }
}
