
package com.mycompany.q10;

public class projectclass implements debugging {//interface impliment calss
    @Override
    public void debug(){
        System.out.println("degugging projectclass:");
    }
    
}
