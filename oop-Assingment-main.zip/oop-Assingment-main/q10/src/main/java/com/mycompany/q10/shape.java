
package com.mycompany.q10;

  public abstract class shape {//Abstract class Shape
    
    
     abstract void nameddraw();
     abstract void erase ();  
}
