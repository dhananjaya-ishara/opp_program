
package com.mycompany.q10;

public interface debugging {//interface call
    void debug();
    
}
