
package com.mycompany.q14;

public class Q14 {

    public static void main(String[] args) {
        Applet_viewer a1=new Applet_viewer();
        a1.show(true);
        
    }
}
