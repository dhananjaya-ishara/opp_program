
package com.mycompany.q7;

public class Monster  extends Item{
    public Monster(int l,String d){
        super(l,d);
    }
    
}
