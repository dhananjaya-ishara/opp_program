
package com.mycompany.q11;

public class ToTestInt extends arithmetic{
    
}
