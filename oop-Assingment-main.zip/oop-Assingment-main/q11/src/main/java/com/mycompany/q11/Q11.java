
package com.mycompany.q11;

public class Q11 {

    public static void main(String[] args) {
        myclass m1=new myclass();
        m1.meth1();
        m1.meth2();
        
        arithmetic a1=new arithmetic();
        a1.square();
        
    }
}
