
package com.mycompany.q11;

public interface test {
    void square();
    
}
