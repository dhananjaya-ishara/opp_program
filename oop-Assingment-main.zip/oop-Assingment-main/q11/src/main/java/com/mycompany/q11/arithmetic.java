
package com.mycompany.q11;

public class arithmetic  implements test{
    //ToTestInt in this class use the object of arithmetic class
    @Override
    public void square(){
        System.out.println("square:");
        
    }
    
}
