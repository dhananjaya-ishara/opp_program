
package com.mycompany.q11;

public class myclass implements A {
    @Override
    public void meth1(){
        System.out.println("meth1:");
        
    }
    @Override
    public void meth2(){
        System.out.println("meth2:");
        
    }
    
}
