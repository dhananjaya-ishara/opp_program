
package com.mycompany.q00000012;

public class Q00000012 {
    public class UserDefinedExceptionExample {

  

    public static void main(String[] args) {
        try {
            // Uncomment the line below to see the custom exception in action
            // throw new CustomException("This is a custom exception");

        } catch (Exception e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        }
    }
    }
}
    







        
    

