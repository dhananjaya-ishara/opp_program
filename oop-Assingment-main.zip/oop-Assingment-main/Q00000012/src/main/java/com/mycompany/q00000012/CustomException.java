
package com.mycompany.q00000012;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}
    
    

